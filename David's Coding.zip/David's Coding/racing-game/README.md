# Sunset Sprint

A standalone canvas racing game. Open `index.html` directly or serve this folder:

```sh
python3 -m http.server 8002 --bind 127.0.0.1 --directory racing-game
```

Visit http://localhost:8002. Arrow keys or A/D change lanes; hold Space for nitro; P or Escape pauses. Touch players can use the on-screen buttons or swipe across the track. Dodge traffic, collect coins, and beat your distance and coin records. Three collisions end the race. Your car gets a short shield after a collision. Nitro recharges when released and must recharge to 25% after being exhausted.

Paint choice and best records use local browser storage, with an in-memory fallback. Sound is opt-in, generated locally. Switching tabs pauses the race. No accounts, network services, external assets, or packages are needed. The chess project is separate and unchanged.
