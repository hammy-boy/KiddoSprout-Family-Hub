# Meteor Patrol

Open index.html or serve this directory on port 8007. Arrows or A/D move; mouse and touch positioning work on the flight deck. The ship fires automatically. Space or the SHIELD button gives three seconds of protection, with a 15-second cooldown from activation. P/Escape pauses; changing tabs pauses automatically.

There are three waves. Armored meteors need two hits. Ship collisions and meteors passing the base cost hull points. Shields protect the ship, not the base. Three hull points per mission. Best score stays in this browser; storage failures fall back to the current visit.

Core tests: node --test meteor-game/engine.test.cjs
Browser tests: node meteor-game/browser-test.cjs
