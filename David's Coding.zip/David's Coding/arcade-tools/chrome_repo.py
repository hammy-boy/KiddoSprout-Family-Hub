import sys, subprocess
from pathlib import Path
js=Path(sys.argv[1]).read_text()
quoted='"'+js.replace('\\','\\\\').replace('"','\\"').replace('\n','\\n').replace('\r','\\r')+'"'
script='''tell application "Google Chrome"
 repeat with w in windows
  repeat with t in tabs of w
   try
   set tabURL to URL of t as text
   if tabURL contains "github.com/hammy-boy/KiddoSprout-Family-Hub" and tabURL does not contain "/blob/" then
    return execute t javascript %s
   end if
   on error errText number errNumber
    if errNumber is not -1719 then error errText number errNumber
   end try
  end repeat
 end repeat
 error "Repository tab not found"
end tell
'''%quoted
r=subprocess.run(['osascript','-'],input=script,capture_output=True,text=True)
if r.returncode:sys.stderr.write(r.stderr);sys.exit(r.returncode)
if len(sys.argv)>2:Path(sys.argv[2]).write_text(r.stdout)
else:print(r.stdout.strip())
