# Little Matches

A standalone memory-matching game with three themes, 6/8/12-pair boards, daily seeded 8-pair garden boards, optional peeks (+2 moves), pause/resume, and saved best scores by board size and theme. Lowest moves wins; elapsed time breaks ties. Daily records are separate and the latest 31 dated records are retained. Timer starts on the first flip or peek; pausing hides the board and stops the timer. Switching tabs automatically pauses an active game. Theme and size changes reset the current game. Records are local to this browser; if storage is unavailable, they last only for the current visit.

Open index.html directly, or from the parent folder run:

    python3 -m http.server 8004 --bind 127.0.0.1 --directory memory-game

Visit http://localhost:8004. Click, tap, or use Tab/Enter to flip cards. Arrow keys move focus between available cards. No external assets, services, or packages are needed. Emoji illustrations use your device's own font.

Tests: node --test memory-game/engine.test.cjs
Browser tests: node memory-game/browser-test.cjs (requires local Chrome).
The Cloudbound link uses the local arcade address; update it when publicly hosting.
