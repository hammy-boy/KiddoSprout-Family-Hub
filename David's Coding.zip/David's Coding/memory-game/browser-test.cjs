// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','game.js','engine.js','style.css','icon.svg'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelectorAll('.card').length===16`);return p}
    const a=await page();
    await send('Emulation.setDeviceMetricsOverride',{width:1360,height:1050,deviceScaleFactor:1,mobile:false},a.sessionId);
    const faces=await a.eval(`[...document.querySelectorAll('.face')].map(x=>x.textContent)`);
    const other=faces.findIndex(f=>f!==faces[0]);
    await a.click('[data-index="0"]');await a.click('[data-index="'+other+'"]');
    assert.equal(await a.eval(`document.querySelector('#moves').textContent`),'1');
    assert.equal(await a.eval(`document.querySelectorAll('.revealed').length`),2);
    await a.until(`document.querySelectorAll('.revealed').length===0`);
    await a.click('#peek');assert.equal(await a.eval(`document.querySelector('#moves').textContent`),'3');
    assert.equal(await a.eval(`document.querySelectorAll('.revealed').length`),16);
    await a.click('#pause');const time=await a.eval(`document.querySelector('#time').textContent`);
    await delay(1100);assert.equal(await a.eval(`document.querySelector('#time').textContent`),time);
    assert.equal(await a.eval(`getComputedStyle(document.querySelector('#board')).visibility`),'hidden');
    await a.click('#continue');await a.until(`document.querySelectorAll('.revealed').length===0`);
    const groups={};faces.forEach((f,i)=>(groups[f]??=[]).push(i));
    for(const pair of Object.values(groups)){for(const i of pair)await a.click('[data-index="'+i+'"]')}
    assert.equal(await a.eval(`document.querySelector('#cover-title').textContent`),'Every pair, found.');
    assert.equal(await a.eval(`document.querySelector('#moves').textContent`),'11');
    assert.equal(JSON.parse(await a.eval(`localStorage.getItem('little-matches-records')`))['normal:garden:8'].moves,11);
    await a.click('#daily');const daily=await a.eval(`[...document.querySelectorAll('.face')].map(x=>x.textContent).join('')`);
    await a.click('#daily');assert.equal(await a.eval(`[...document.querySelectorAll('.face')].map(x=>x.textContent).join('')`),daily);
    await a.click('[data-theme="space"]');
    await a.eval(`document.querySelector('#difficulty').value='12';document.querySelector('#difficulty').dispatchEvent(new Event('change'))`);
    assert.equal(await a.eval(`document.querySelectorAll('.card').length`),24);
    await a.click('#peek');await a.click('#new-game');await delay(1700);
    assert.equal(await a.eval(`document.querySelector('#moves').textContent`),'0');assert.equal(await a.eval(`document.querySelectorAll('.revealed').length`),0);
    await a.eval(`document.querySelector('#difficulty').value='8';document.querySelector('#difficulty').dispatchEvent(new Event('change'))`);
    await a.click('[data-theme="garden"]');
    await a.click('#peek');
    const desktop=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync(path.join(folder,'memory-desktop.png'),Buffer.from(desktop.data,'base64'));
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    const mobile=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync(path.join(folder,'memory-mobile.png'),Buffer.from(mobile.data,'base64'));
    assert.deepEqual(errors,[]);
    console.log('PASS: mismatches, hint cost, pause/resume, complete board, saved records, daily shuffle, themes, difficulty, reset during hint and mobile layout. Screenshots: '+folder);
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
