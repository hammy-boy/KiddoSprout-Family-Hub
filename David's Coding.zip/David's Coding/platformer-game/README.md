# Cloudbound

A standalone three-level platformer. Open index.html directly, or from the parent workspace run:

    python3 -m http.server 8003 --bind 127.0.0.1 --directory platformer-game

Visit http://localhost:8003. Move with arrows or A/D; Space, Up or W jumps (press twice to double jump). P/Escape pauses. Touch controls support holding a direction while tapping Jump. Stomp enemies, collect 30 optional gems, reach the checkpoint and finish each chapter at its flag. Three lives per expedition. Checkpoints last for the current run; gem records persist in this browser. Sound is opt-in. The racing arcade link uses its existing localhost:8002 address; change it when hosting publicly.

Run engine checks: node --test platformer-game/engine.test.cjs
