// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'index.html':req.url.slice(1);if(!['index.html','game.js','engine.js','style.css','icon.svg'].includes(name)){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelector('#world') && document.querySelector('#start')`);return p}
    const a=await page();
    await send('Emulation.setDeviceMetricsOverride',{width:1360,height:1050,deviceScaleFactor:1,mobile:false},a.sessionId);
    await a.click('#start');
    await a.eval(`document.querySelector('#world').dispatchEvent(new KeyboardEvent('keydown',{code:'ArrowRight',bubbles:true}))`);
    await delay(650);
    await a.eval(`document.querySelector('#world').dispatchEvent(new KeyboardEvent('keyup',{code:'ArrowRight',bubbles:true}))`);
    assert.ok(Number(await a.eval(`document.querySelector('#gems').textContent`))>=1);
    await a.eval(`document.querySelector('#world').dispatchEvent(new KeyboardEvent('keydown',{code:'Space',bubbles:true}))`);
    await delay(150);
    await a.eval(`document.querySelector('#world').dispatchEvent(new KeyboardEvent('keydown',{code:'Space',bubbles:true}))`);
    await delay(200);
    const desktop=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);
    fs.writeFileSync(path.join(folder,'platformer-desktop.png'),Buffer.from(desktop.data,'base64'));
    await a.click('#pause');
    assert.equal(await a.eval(`document.querySelector('#overlay-title').textContent`),'A moment in the clouds.');
    await a.click('#start');
    assert.equal(await a.eval(`document.querySelector('#overlay').hidden`),true);
    assert.ok(Number(await a.eval(`localStorage.getItem('cloudbound-best')`))>=1);
    await a.click('#pause');
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);
    await delay(150);
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    assert.equal(await a.eval(`document.querySelector('#world').width`),720);
    const mobile=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);
    fs.writeFileSync(path.join(folder,'platformer-mobile.png'),Buffer.from(mobile.data,'base64'));
    assert.deepEqual(errors,[]);
    console.log('PASS: browser start, keyboard movement, gem collection, double-jump input, pause/resume, saved record and mobile layout. Screenshots: '+folder);
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
