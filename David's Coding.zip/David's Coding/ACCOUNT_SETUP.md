# Optional academy login

Implementation is ready for a dedicated Supabase Auth project. It is **not activated with real accounts yet**. Guest play works now, including with empty account settings. Verify real email sign-in before advertising account login as available.

## Connect the academy

1. Choose or create a dedicated academy Supabase project. Do not reuse an unrelated project's accounts.
2. Enable email authentication and account creation. Keep anonymous sign-in disabled.
3. Configure production email delivery (custom SMTP) and the email templates to include `{{ .Token }}` for login and signup confirmation, so users receive a code. Supabase's built-in email service is limited; new Free projects may require custom SMTP before template changes are available. Configure provider rate limits and test delivery to a non-owner address.
4. Set `url` and `publishableKey` in `public/auth-config.js`, and the matching file in `chess-public/public/`. Only use the public `sb_publishable_…` key. Never include a secret or service-role key.
5. If running the Node server, set `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` to the same project values. Guest requests work without an account provider; requests claiming an account must pass verification. GitHub Pages has no game API server.
6. Verify a real new account, returning account, incorrect/expired code, sign-out, session expiry, and a direct study-room URL. Then publish to the existing academy repository.

## Behavior and limits

Visitors can choose **Play as guest** without providing an email, or optionally sign in with an emailed code. Guest mode is remembered in this tab, works across academy pages, and provides a Log in button. It is never represented as a verified account. The existing room/tournament capability tokens still protect individual games.

Verified account access tokens stay in session storage for this tab; refresh tokens are not stored. Missing configuration, invalid tokens and outages cannot create a verified identity, but visitors can choose guest play. Account sign-in needs internet. Guests can open already-cached game assets offline.

GitHub Pages serves public HTML/JavaScript. Optional login verifies account identity, not access to public chess source code. Node game APIs independently validate any supplied account identity with Supabase. They still require their existing room/tournament capability tokens for access to particular games. Accounts do not yet sync or separate historical device-local progress; the login screen states this clearly. No database tables or RLS policies are introduced by this change.

## Verification

`node --test tests/account-auth.test.cjs` tests guest access and rejection of invalid claimed accounts, missing configuration, outages, anonymous/unverified accounts and forged identity metadata. `node tests/browser.cjs` exercises login, invalid codes, forged sessions, logout, deep links, then the existing game regression checks. Browser tests use a simulated provider; they do not prove live email delivery. Existing game API tests inject an explicit test identity through `tests/server-fixture.cjs`; guest requests in production need no account credential.

References: https://supabase.com/docs/guides/auth/auth-email-passwordless and https://github.com/supabase/auth/blob/master/openapi.yaml
