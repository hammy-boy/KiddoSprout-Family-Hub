const {test}=require('node:test'),assert=require('node:assert/strict');
const C=require('../lib/chess-core.js'),T=require('../public/training.js');
const uci=m=>C.square(m.from)+C.square(m.to)+(m.promotion||'');
const moves=s=>C.allMoves(s).flatMap(m=>s.board[m.from].toLowerCase()==='p'&&(m.to<8||m.to>=56)?['q','r','b','n'].map(promotion=>({...m,promotion})):[m]);
function mates(s){return moves(s).filter(m=>{const n=C.apply(s,m);return C.check(n,n.turn)&&moves(n).length===0})}
test('every expert puzzle needs two moves and covers every legal defence',()=>{
 assert.equal(T.expert.filter(p=>!p.deep).length,16);
 for(const item of T.expert.filter(p=>!p.deep)){const start=C.fromFEN(item.fen);assert.equal(C.check(start,'w'),false);assert.equal(C.check(start,'b'),false);assert.equal(mates(start).length,0,item.id+' must not have mate in one');
 const winning=[];
 for(const first of moves(start)){const next=C.apply(start,first),replies=moves(next);if(replies.length&&replies.every(reply=>mates(C.apply(next,reply)).length))winning.push(uci(first))}
 assert.deepEqual(Object.keys(item.plans).sort(),winning.sort(),item.id+' includes all correct first moves');
 for(const [first,branches] of Object.entries(item.plans)){const next=C.apply(start,C.moveFromUCI(start,first));assert.deepEqual(Object.keys(branches).sort(),moves(next).map(uci).sort());for(const [reply,solutions]of Object.entries(branches)){const finish=C.apply(next,C.moveFromUCI(next,reply));assert.deepEqual(solutions.slice().sort(),mates(finish).map(uci).sort())}}
 }
});

test('deep puzzles cover every defence and finish in mate in three or four',()=>{
 const deep=T.expert.filter(p=>p.deep);assert.equal(deep.length,4);
 function inspect(s,tree,remaining){assert.ok(remaining>0);assert.ok(Object.keys(tree).length);for(const [move,branches]of Object.entries(tree)){const legal=moves(s).find(m=>uci(m)===move);assert.ok(legal,move);const next=C.apply(s,legal),replies=moves(next);if(branches===true){assert.equal(replies.length,0);assert.ok(C.check(next,next.turn));continue}assert.deepEqual(Object.keys(branches).sort(),replies.map(uci).sort());assert.ok(replies.length);for(const reply of replies)inspect(C.apply(next,reply),branches[uci(reply)],remaining-1)}}
 for(const item of deep){const s=C.fromFEN(item.fen);assert.equal(mates(s).length,0);assert.ok(s.board.filter(Boolean).length>=7);inspect(s,item.plans,item.mateMoves);let n=s;for(const u of item.line){const m=moves(n).find(m=>uci(m)===u);assert.ok(m);n=C.apply(n,m)}assert.ok(C.check(n,n.turn));assert.equal(moves(n).length,0);assert.equal(item.line.length,item.mateMoves*2-1)}
});
