// Explicit identity fixture for game-rule/API tests. Production has no guest mode.
const {createChessServer:realServer}=require('../server.cjs');
exports.createChessServer=options=>realServer({verifyAccount:async()=>({id:'test-account'}),...options});
