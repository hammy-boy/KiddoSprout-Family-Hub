const {test}=require('node:test'),assert=require('node:assert/strict');
const C=require('../lib/chess-core.js'),S=require('../chess-extras/study-core.js');
test('full game review rates every legal move and spots a mating blunder',()=>{
 const game=S.parsePGN('1. f3 e5 2. g4 Qh4#'),results=[];
 for(let i=0;i<game.notation.length;i++){const result=S.analyseMove(game.states[i],game.states[i+1],{depth:2,nodeLimit:8000});results.push(result);assert.ok(result.depth>=1);assert.ok(C.moveFromUCI(game.states[i],result.best));assert.ok(result.accuracy>=0&&result.accuracy<=100);assert.equal(result.side,game.states[i].turn);assert.ok(result.loss>=0)}
 assert.equal(results[2].label,'Blunder');assert.ok(results[2].score<-29900);assert.equal(results[3].label,'Best');assert.equal(results[3].loss,0);assert.equal(results[3].accuracy,100);
});
test('review finds played castling, en passant and underpromotion moves',()=>{
 for(const [fen,uci] of [['4k3/8/8/8/8/8/8/4K2R w K - 0 1','e1g1'],['7k/8/8/3pP3/8/8/8/6K1 w - d6 0 1','e5d6'],['7k/P7/6K1/8/8/8/8/8 w - - 0 1','a7a8n']]){
 const before=C.fromFEN(fen),after=C.apply(before,C.moveFromUCI(before,uci)),original=JSON.stringify(before);const result=S.analyseMove(before,after,{depth:1,nodeLimit:2000});assert.equal(result.played,uci);assert.equal(JSON.stringify(before),original);
 }
 assert.throws(()=>S.analyseMove(C.initial(),C.initial()),/legal move/);
});
test('review labels have explicit loss thresholds and forced moves',()=>{
 assert.equal(S.classifyMove(0,100,100),'Best');assert.equal(S.classifyMove(15,100,85),'Excellent');assert.equal(S.classifyMove(50,100,50),'Good');assert.equal(S.classifyMove(100,100,0),'Inaccuracy');assert.equal(S.classifyMove(200,100,-100),'Mistake');assert.equal(S.classifyMove(300,100,-200),'Blunder');assert.equal(S.classifyMove(0,-29999,-29999,true),'Best');assert.equal(S.classifyMove(29000,29999,999),'Miss');
});

test('mistake explanation shows a legal mating reply without changing the game',()=>{
 const game=S.parsePGN('1. f3 e5 2. g4 Qh4#'),after=game.states[3],snapshot=JSON.stringify(after);
 const result=S.analyseMove(game.states[2],after,{depth:2,nodeLimit:8000});
 assert.equal(result.reply.uci,'d8h4');assert.equal(result.reply.san,'Qh4#');
 assert.match(result.reply.reason,/checkmate/);assert.match(result.explanation,/opponent can play Qh4#/);
 const reply=C.moveFromUCI(after,result.reply.uci),next=C.apply(after,reply);
 assert.equal(C.allMoves(next).length,0);assert.equal(C.check(next,next.turn),true);
 assert.equal(JSON.stringify(after),snapshot);
});

test('special move labels require their supporting evidence',()=>{
 assert.equal(S.classifyMove(0,100,100,false,{book:true}),'Book');
 assert.equal(S.classifyMove(10,310,300,false,{depth:2,sacrifice:true}),'Brilliant');
 assert.equal(S.classifyMove(10,100,90,false,{depth:1,sacrifice:true}),'Excellent');
 assert.equal(S.classifyMove(0,-200,-200,false,{depth:2,sacrifice:true}),'Best');
 assert.equal(S.classifyMove(0,100,100,false,{depth:2,secondScore:-100,positionScore:0}),'Great');
 assert.equal(S.classifyMove(0,100,100,false,{depth:1,secondScore:-100}),'Best');
});
test('book classification recognises a real opening and ignores unknown moves',()=>{
 const before=C.initial(),book=C.apply(before,C.moveFromUCI(before,'e2e4'));
 const result=S.analyseMove(before,book,{depth:1,nodeLimit:2000});assert.equal(result.label,'Book');assert.match(result.explanation,/Italian Game/);
 const other=C.apply(before,C.moveFromUCI(before,'a2a3'));assert.notEqual(S.analyseMove(before,other,{depth:1,nodeLimit:2000}).label,'Book');
});

test('Great requires an only-good outcome and Brilliant requires a decisive sacrifice',()=>{
 assert.equal(S.classifyMove(0,600,600,false,{depth:3,secondScore:400,positionScore:500}),'Best');
 assert.equal(S.classifyMove(0,190,190,false,{depth:3,secondScore:0,positionScore:0}),'Best');
 assert.equal(S.classifyMove(0,250,250,false,{depth:3,secondScore:0,positionScore:0}),'Great');
 assert.equal(S.classifyMove(0,250,250,false,{depth:3,secondScore:0,positionScore:0,sacrifice:true}),'Brilliant');
 assert.equal(S.classifyMove(0,50,50,false,{depth:3,sacrifice:true}),'Best');
});
test('material offers include pawns and equal-valued capturers but exclude ordinary trades',()=>{
 for(const [fen,uci] of [['7k/8/8/4p3/8/3P4/8/K7 w - - 0 1','d3d4'],['7k/8/8/4p3/8/2PP4/8/K7 w - - 0 1','d3d4']]){
 const before=C.fromFEN(fen),after=C.apply(before,C.moveFromUCI(before,uci));
 assert.equal(!!S.sacrificeEvidence(before,after),!fen.includes('2PP4'));
 }
 const before=C.fromFEN('r6k/8/8/8/8/8/1R6/7K w - - 0 1'),after=C.apply(before,C.moveFromUCI(before,'b2a2'));
 assert.equal(S.sacrificeEvidence(before,after).value,500);
});

test('a queen sacrifice with proven smothered mate is Brilliant even on quick search',()=>{
 const before=C.fromFEN('5r1k/6pp/4Q2N/8/8/8/8/6K1 w - - 0 1');
 const move=C.moveFromUCI(before,'e6g8');assert.ok(move);const after=C.apply(before,move);
 const result=S.analyseMove(before,after,{depth:1,nodeLimit:1000});
 assert.equal(result.label,'Brilliant');assert.ok(result.mateProof);assert.match(result.explanation,/every legal defence/);
});
test('mate proof does not assume the opponent accepts a sacrifice',()=>{
 assert.equal(S.sacrificeMate(C.initial(),'b'),null);
 assert.equal(S.sacrificeMate(C.initial(),'b',6,1),null);
});
