# Orbit Snake

Open index.html or serve the folder on port 8006. Arrow keys/WASD, swipe, or direction buttons turn the snake. P/Escape pauses. Three speeds have separate local high scores. Avoid the walls and your tail; collect stars to grow. Switching tabs pauses. A full 20×20 board wins.

Tests: node --test snake-game/engine.test.cjs
