(function(root){
const pos=(r,c)=>({x:40+c*40+(r%2)*20,y:52+r*35}),valid=(r,c)=>r>=0&&r<12&&c>=0&&c<(r%2?9:10),key=(r,c)=>r+','+c;
class Harbor{
 constructor(random=Math.random){this.random=random;this.reset()}
 reset(){this.score=0;this.load(0)}
 load(level){this.level=level;this.board=new Map();for(let r=0;r<4+level;r++)for(let c=0;c<(r%2?9:10);c++)this.board.set(key(r,c),{r,c,color:(Math.floor(c/3)+Math.floor(r/2))%(level?4:3)});this.shots=20+level*3;this.status='playing';this.ball=null;this.lastPop=0;this.current=this.pick();this.next=this.pick()}
 pick(){const colors=[...new Set([...this.board.values()].map(b=>b.color))];return colors[Math.floor(this.random()*colors.length)]??0}
 neighbors(r,c){const offset=r%2?1:-1;return [[r,c-1],[r,c+1],[r-1,c],[r-1,c+offset],[r+1,c],[r+1,c+offset]].filter(([a,b])=>valid(a,b))}
 shoot(angle){if(this.status!=='playing'||this.ball)return false;angle=Math.max(-Math.PI+.32,Math.min(-.32,angle));this.ball={x:220,y:595,vx:Math.cos(angle)*470,vy:Math.sin(angle)*470,color:this.current};this.shots--;return true}
 step(dt){for(let left=Math.min(.05,dt);left>0&&this.ball;){const t=Math.min(left,1/240);left-=t;const b=this.ball;b.x+=b.vx*t;b.y+=b.vy*t;if(b.x<20){b.x=40-b.x;b.vx=Math.abs(b.vx)}if(b.x>420){b.x=840-b.x;b.vx=-Math.abs(b.vx)}if(b.y<=52){const candidates=[];for(let c=0;c<10;c++)if(!this.board.has(key(0,c)))candidates.push([0,c]);this.attach(candidates);continue}const hit=[...this.board.values()].find(v=>{const p=pos(v.r,v.c);return Math.hypot(p.x-b.x,p.y-b.y)<38});if(hit)this.attach(this.neighbors(hit.r,hit.c).filter(([r,c])=>!this.board.has(key(r,c))))}}
 attach(candidates){const b=this.ball;if(!b)return;if(!candidates.length){this.status='over';this.ball=null;return}candidates.sort((a,z)=>{const p=pos(...a),q=pos(...z);return Math.hypot(p.x-b.x,p.y-b.y)-Math.hypot(q.x-b.x,q.y-b.y)});const [r,c]=candidates[0],start=key(r,c);this.board.set(start,{r,c,color:b.color});this.ball=null;
 const group=new Set([start]),queue=[start];while(queue.length){const n=this.board.get(queue.pop());for(const [nr,nc]of this.neighbors(n.r,n.c)){const k=key(nr,nc),v=this.board.get(k);if(v&&v.color===b.color&&!group.has(k)){group.add(k);queue.push(k)}}}this.lastPop=0;if(group.size>=3){for(const k of group)this.board.delete(k);this.score+=group.size*10;this.lastPop=group.size;const attached=new Set(),todo=[];for(const [k,v]of this.board)if(v.r===0){attached.add(k);todo.push(k)}while(todo.length){const v=this.board.get(todo.pop());for(const [nr,nc]of this.neighbors(v.r,v.c)){const k=key(nr,nc);if(this.board.has(k)&&!attached.has(k)){attached.add(k);todo.push(k)}}}for(const k of this.board.keys())if(!attached.has(k)){this.board.delete(k);this.score+=15;this.lastPop++}}
 if(!this.board.size)this.status=this.level===2?'won':'complete';else if(this.shots<=0||[...this.board.values()].some(v=>v.r===11))this.status='over';else{this.current=[...this.board.values()].some(v=>v.color===this.next)?this.next:this.pick();this.next=this.pick()}
 }
 swap(){if(this.status==='playing'&&!this.ball)[this.current,this.next]=[this.next,this.current]}
}
const api={Harbor,pos,valid,key};if(typeof module==='object'&&module.exports)module.exports=api;else root.BubbleHarbor=api;
})(globalThis);
