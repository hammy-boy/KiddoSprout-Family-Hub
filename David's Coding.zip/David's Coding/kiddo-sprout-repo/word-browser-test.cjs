// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'games/index.html':req.url.split('?')[0].slice(1);if(!(name.startsWith('games/')||name==='kid-hub-gate.js')||name.includes('..')){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name.endsWith('/')?name+'index.html':name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base+'/games/'},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);return p}
    const a=await page(); console.log('Anonymous gate passed');
    assert.equal(await a.eval(`getComputedStyle(document.querySelector('[data-hub-page]')).display`),'none');
    await a.eval(`localStorage.setItem('kiddosproutState',JSON.stringify({parentAccountCreated:true,activeChild:0,children:[{appRules:{arcade:'allowed'}}]}))`);
    await send('Page.navigate',{url:base+'/games/word-builder/'},a.sessionId);
    await a.until(`document.querySelectorAll('[data-garden]').length===4`);
    assert.equal(await a.eval(`document.querySelectorAll('[data-garden]:disabled').length`),3);
    for(const name of ['seedlings','blossoms','orchard','meadow']){
      await a.click(`[data-garden="${name}"]`);
      for(let n=0;n<6;n++){
        if(n===0){
          await a.eval(`[...document.querySelectorAll('.tile')].forEach(b=>b.click())`);
          await a.click('#check');
          assert.equal(await a.eval(`document.querySelector('#message').textContent`),'Almost — try a different order.');
          await a.click('#hint');
          assert.equal(await a.eval(`document.querySelectorAll('.slot.filled').length>0`),true);
          await a.click('#clear');
          await a.eval(`document.dispatchEvent(new KeyboardEvent('keydown',{key:document.querySelector('.tile').textContent,bubbles:true}));document.dispatchEvent(new KeyboardEvent('keydown',{key:'Backspace',bubbles:true}))`);
          assert.equal(await a.eval(`document.querySelectorAll('.slot.filled').length`),0);
        }
        await a.eval(`(()=>{const row=WordGarden.gardens.find(g=>g.id==='${name}').words.find(w=>w[2]===document.querySelector('#clue').textContent);for(const ch of row[0])document.dispatchEvent(new KeyboardEvent('keydown',{key:ch,bubbles:true}))})()`);
        await a.click('#check');
        assert.equal(await a.eval(`document.querySelector('#message').textContent`),'Your word has bloomed!');
        assert.equal(await a.eval(`document.querySelectorAll('.tile:not(:disabled)').length`),0);
        await a.click('#next');
      }
      assert.equal(await a.eval(`JSON.parse(localStorage.getItem('sprout-word-gardens'))['${name}'].best`),5);
      await a.click('#review');
      assert.equal(await a.eval(`document.querySelector('#step').textContent`),'Word 1 / 1');
      await a.eval(`(()=>{const row=WordGarden.gardens.find(g=>g.id==='${name}').words.find(w=>w[2]===document.querySelector('#clue').textContent);for(const ch of row[0]){[...document.querySelectorAll('.tile')].find(b=>!b.disabled&&b.textContent===ch).click()}})()`);
      await a.click('#check');await a.click('#next');
      assert.equal(await a.eval(`document.querySelector('#result-title').textContent`),'Practice complete!');
      assert.equal(await a.eval(`document.querySelector('#review').classList.contains('hidden')`),true);
      await a.click('#return');console.log('PASS: '+name+' spelling, hints, duplicate letters, keyboard, review and progress');
    }
    assert.equal(await a.eval(`document.querySelector('#progress').textContent`),'4 / 4 gardens grown');
    await send('Page.reload',{},a.sessionId);await a.until(`document.querySelector('#progress')?.textContent==='4 / 4 gardens grown'`);
    assert.equal(await a.eval(`document.querySelectorAll('[data-garden]:disabled').length`),0);
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/word-desktop.png',Buffer.from(shot.data,'base64'));
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);
    await a.click('[data-garden="meadow"]');
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    const mobileShot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/word-mobile.png',Buffer.from(mobileShot.data,'base64'));
    await a.eval(`const s=JSON.parse(localStorage.getItem('kiddosproutState'));s.children[0].appRules.arcade='blocked';localStorage.setItem('kiddosproutState',JSON.stringify(s))`);
    await a.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);
    assert.equal(await a.eval(`document.querySelector('script[src="game.js"]')===null`),true);
    assert.deepEqual(errors,[]);console.log('PASS: garden unlocks, persistence, mobile layout, and parent approval gates');
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
