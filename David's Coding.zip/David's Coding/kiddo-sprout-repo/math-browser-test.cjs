// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'games/index.html':req.url.split('?')[0].slice(1);if(!(name.startsWith('games/')||name==='kid-hub-gate.js')||name.includes('..')){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name.endsWith('/')?name+'index.html':name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base+'/games/'},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);return p}
    const a=await page(); console.log('Anonymous gate passed');
    assert.equal(await a.eval(`getComputedStyle(document.querySelector('[data-hub-page]')).display`),'none');
    await a.eval(`localStorage.setItem('kiddosproutState',JSON.stringify({parentAccountCreated:true,activeChild:0,children:[{appRules:{arcade:'allowed'}}]}))`);
    await send('Page.navigate',{url:base+'/games/multiplication-runner/'},a.sessionId);
    await a.until(`document.querySelector('#table')?.options.length===12`);
    for(const op of ['multiply','add','subtract','divide']){
      await a.eval(`document.querySelector('#operation').value='${op}';document.querySelector('#operation').dispatchEvent(new Event('change'));document.querySelector('#table').value='3'`);
      await a.click('#start');
      assert.equal(await a.eval(`document.querySelector('#landscape').dataset.phase`),'running');
      await a.click('#jump');
      await a.until(`document.querySelector('#landscape').dataset.phase==='question'`);
      const expected=await a.eval(`(()=>{const [x,s,y]=document.querySelector('#question').textContent.split(' ');return s==='×'?+x*+y:s==='÷'?+x/+y:s==='+'?+x+ +y:+x- +y})()`);
      await a.eval(`(()=>{const b=[...document.querySelectorAll('.answer')].find(b=>Number(b.firstChild.textContent)!==${expected});b.click()})()`);
      assert.equal(await a.eval(`document.querySelector('#message').textContent`),'Keep going — try another gate.');
      await a.eval(`(()=>{const b=[...document.querySelectorAll('.answer')].find(b=>Number(b.firstChild.textContent)===${expected});b.click()})()`);
      assert.equal(await a.eval(`document.querySelector('#stars').textContent`),'★ 0 first tries');
      for(let n=1;n<10;n++){
        await a.click('#next');
        await a.until(`document.querySelector('#landscape').dataset.phase==='question'`);
        await a.eval(`(()=>{const [x,s,y]=document.querySelector('#question').textContent.split(' ');const answer=s==='×'?+x*+y:s==='÷'?+x/+y:s==='+'?+x+ +y:+x- +y;const i=[...document.querySelectorAll('.answer')].findIndex(b=>Number(b.firstChild.textContent)===answer);document.dispatchEvent(new KeyboardEvent('keydown',{key:String(i+1),bubbles:true}))})()`);
      }
      await a.click('#next');
      assert.equal(await a.eval(`document.querySelector('#question').textContent`),'9 / 10 ★');
      assert.equal(await a.eval(`document.querySelector('#best').textContent`),'Best: 9 / 10');
      assert.equal(await a.eval(`document.querySelector('#operation').disabled`),false);
      console.log('PASS: '+op+' full run, hints, keyboard answers and saved score');
    }
    assert.equal(await a.eval(`Object.keys(JSON.parse(localStorage.getItem('sprout-math-islands'))).length`),4);
    assert.equal(await a.eval(`document.querySelectorAll('#checkpoints .done').length`),10);
    const shot=await send('Page.captureScreenshot',{format:'png'},a.sessionId);fs.writeFileSync('/private/tmp/math-map-desktop.png',Buffer.from(shot.data,'base64'));
    await a.eval(`document.querySelector('#pace').value='sprint'`);await a.click('#start');await a.until(`document.querySelector('#landscape').dataset.phase==='question'`);await a.click('#pause');
    assert.equal(await a.eval(`document.querySelector('#timer').textContent`),'Paused');
    assert.equal(await a.eval(`[...document.querySelectorAll('.answer')].every(b=>b.disabled)`),true);
    await delay(1000);assert.equal(await a.eval(`document.querySelector('#timer').textContent`),'Paused');
    await a.click('#pause');await a.until(`!document.querySelector('#next').classList.contains('hidden')`);
    assert.equal(await a.eval(`document.querySelector('#message').textContent`),'Let’s learn this one together.');
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    const mobileShot=await send('Page.captureScreenshot',{format:'png'},a.sessionId);fs.writeFileSync('/private/tmp/math-map-mobile.png',Buffer.from(mobileShot.data,'base64'));
    await a.click('#start');
    await a.eval(`const s=JSON.parse(localStorage.getItem('kiddosproutState'));s.children[0].appRules.arcade='blocked';localStorage.setItem('kiddosproutState',JSON.stringify(s))`);
    await a.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);
    assert.equal(await a.eval(`document.querySelector('script[src="game.js"]')===null`),true);
    assert.deepEqual(errors,[]);console.log('PASS: Math Runner sprint expiry, pause, mobile layout, and revoked parent approval');
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
