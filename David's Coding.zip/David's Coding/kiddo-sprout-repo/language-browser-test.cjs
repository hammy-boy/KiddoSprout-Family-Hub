// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'games/index.html':req.url.split('?')[0].slice(1);if(!(name.startsWith('games/')||name==='kid-hub-gate.js')||name.includes('..')){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name.endsWith('/')?name+'index.html':name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base+'/games/'},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);return p}
    const a=await page(); console.log('Anonymous gate passed');
    assert.equal(await a.eval(`getComputedStyle(document.querySelector('[data-hub-page]')).display`),'none');
    await a.eval(`localStorage.setItem('kiddosproutState',JSON.stringify({parentAccountCreated:true,activeChild:0,children:[{appRules:{arcade:'allowed'}}]}))`);
    await send('Page.navigate',{url:base+'/games/language-garden/'},a.sessionId);
    await a.until(`document.querySelectorAll('[data-language]').length===48`);
    assert.equal(await a.eval(`LanguageCatalogue.languages.length`),7923);
    for(const code of ['yo','ig','ha']){await a.click('[data-open-language="'+code+'"]');assert.equal(await a.eval(`document.querySelector('#flash').disabled`),false);await a.click('#back');}
    await a.eval(`document.querySelector('#search').value='ypruba';document.querySelector('#search').dispatchEvent(new Event('input'))`);
    assert.equal(await a.eval(`document.querySelector('[data-language]').dataset.language`),'yo');
    await a.eval(`document.querySelector('#search').value='';document.querySelector('#search').dispatchEvent(new Event('input'))`);
    await a.eval(`document.querySelector('#filter').value='all';document.querySelector('#filter').dispatchEvent(new Event('change'))`);
    await a.click('#more');assert.equal(await a.eval(`document.querySelectorAll('[data-language]').length`),96);
    await a.eval(`document.querySelector('#filter').value='courses';document.querySelector('#filter').dispatchEvent(new Event('change'))`);
    assert.equal(await a.eval(`document.querySelectorAll('[data-language]').length`),48);await a.click('#more');assert.equal(await a.eval(`document.querySelectorAll('[data-language]').length`),50);
    await a.click('[data-language="es"]');await a.click('#tutor-start');await a.click('#tutor-begin');
    for(let n=0;n<5;n++){
      if(n===0){await a.eval(`document.querySelector('#tutor-answer').value='wrong';document.querySelector('#tutor-form').requestSubmit()`);await a.click('#tutor-hint');}
      if(n===1)await a.click('#tutor-reveal');
      else await a.eval(`(()=>{const prompt=document.querySelector('#tutor-prompt').textContent;const c=LanguageGarden.courses.es.cards.find(c=>c.text===prompt);document.querySelector('#tutor-answer').value=c.meaning;document.querySelector('#tutor-form').requestSubmit()})()`);
      await a.click('#tutor-next');
    }
    assert.equal(await a.eval(`document.querySelector('#tutor-step').textContent`),'3 of 5 without help');
    assert.equal(await a.eval(`JSON.parse(localStorage.getItem('sprout-language-tutor')).es.lastCorrect`),3);
    await a.click('#tutor-review');
    for(let n=0;n<2;n++){await a.eval(`(()=>{const prompt=document.querySelector('#tutor-prompt').textContent;const c=LanguageGarden.courses.es.cards.find(c=>c.text===prompt);document.querySelector('#tutor-answer').value=c.meaning;document.querySelector('#tutor-form').requestSubmit()})()`);await a.click('#tutor-next');}
    assert.equal(await a.eval(`document.querySelector('#tutor-step').textContent`),'2 of 2 without help');
    await a.eval(`document.querySelector('#tutor-direction').value='word';document.querySelector('#tutor-direction').dispatchEvent(new Event('change'));document.querySelector('#tutor-topic').value='Colours'`);await a.click('#tutor-begin');
    assert.equal(await a.eval(`document.querySelector('#tutor-step').textContent.endsWith(' · Colours')`),true);
    await a.eval(`(()=>{const c=LanguageGarden.courses.es.cards.find(c=>c.meaning===document.querySelector('#tutor-prompt').textContent);document.querySelector('#tutor-answer').value=c.text;document.querySelector('#tutor-form').requestSubmit()})()`);
    assert.equal(await a.eval(`document.querySelector('#tutor-next').disabled`),false);
    await a.click('#back');assert.equal(await a.eval(`document.querySelector('#tutor-panel').classList.contains('hidden')`),true);
    await a.click('[data-language="he"]');await a.click('#tutor-start');await a.click('#tutor-begin');
    assert.equal(await a.eval(`document.querySelector('#tutor-answer').dir`),'rtl');
    await a.click('#back');console.log('PASS: tutor hints, typed answers, assisted scoring, revisit, topics, persistence, direction and RTL');
    for(const [id,course] of Object.entries(require('./games/language-garden/courses.js').courses)){ 
      if(!await a.eval(`document.querySelector('[data-language="${id}"]')!==null`))await a.click('#more');
      await a.click(`[data-language="${id}"]`);await a.click('#flash');await a.click('#reveal');assert.equal(await a.eval(`document.querySelector('#study-message').textContent.length>0`),true);await a.click('#close-study');
      await a.click('#quiz');
      for(let n=0;n<course.cards.length;n++){
        await a.eval(`(()=>{const target=document.querySelector('#study-word').textContent;const card=LanguageGarden.courses['${id}'].cards.find(c=>c.text===target&&document.querySelector('#study-type').textContent.endsWith(' · '+c.topic));const choice=[...document.querySelectorAll('.choice')].find(b=>${n===0?'b.textContent!==card.meaning':'b.textContent===card.meaning'});choice.click()})()`);
        assert.equal(await a.eval(`[...document.querySelectorAll('.choice')].every(b=>b.disabled)`),true);
        if(id==='nb')assert.equal(await a.eval(`document.querySelector('#study-word').textContent!=='tre'||![...document.querySelectorAll('.choice')].some(b=>b.textContent===(document.querySelector('#study-type').textContent.endsWith(' · Nature')?'Three':'Tree'))`),true);
        if(['ar','he','fa','ur'].includes(id))assert.equal(await a.eval(`document.querySelector('#study-word').dir`),'rtl');
        await a.click('#study-next');
      }
      assert.equal(await a.eval(`document.querySelector('#study-message').textContent`),`${course.cards.length-1} of ${course.cards.length} meanings remembered.`);
      await a.click('#study-next');await a.click('#back');console.log('PASS: '+id+' flashcards, quiz, feedback and progress');
    }
    await a.eval(`document.querySelector('#filter').value='all';document.querySelector('#filter').dispatchEvent(new Event('change'));document.querySelector('#search').value='Albanian';document.querySelector('#search').dispatchEvent(new Event('input'))`);
    await a.click('[data-language="sq"]');assert.equal(await a.eval(`document.querySelector('#flash').disabled`),true);assert.equal(await a.eval(`document.querySelector('#availability').textContent.includes('no starter course')`),true);
    await a.click('#bookmark');
    await a.eval(`document.querySelector('#custom-text').value='<img src=x onerror=alert(1)>';document.querySelector('#custom-meaning').value='Safe test text';document.querySelector('#custom-note').value='A test card';document.querySelector('#add-word').requestSubmit()`);
    assert.equal(await a.eval(`document.querySelector('#word-list img')===null`),true);assert.equal(await a.eval(`document.querySelector('#word-list strong').textContent`),'<img src=x onerror=alert(1)>');
    await a.click('#tutor-start');await a.eval(`document.querySelector('#tutor-direction').value='meaning'`);await a.click('#tutor-begin');
    assert.equal(await a.eval(`document.querySelector('#tutor-prompt img')===null`),true);
    assert.equal(await a.eval(`document.querySelector('#tutor-prompt').textContent`),'<img src=x onerror=alert(1)>');
    await a.click('#tutor-reveal');await a.click('#tutor-next');await a.click('#tutor-close');
    await a.eval(`document.querySelector('#custom-text').value='Another test word';document.querySelector('#custom-meaning').value='Another meaning';document.querySelector('#add-word').requestSubmit()`);
    assert.equal(await a.eval(`document.querySelector('#quiz').disabled`),false);
    await a.click('#flash');
    assert.equal(await a.eval(`document.querySelector('#speak').disabled`),true);await a.click('#close-study');
    await send('Page.reload',{},a.sessionId);await a.until(`document.querySelectorAll('[data-language]').length===48`);
    await a.eval(`document.querySelector('#filter').value='saved';document.querySelector('#filter').dispatchEvent(new Event('change'))`);await a.click('[data-language="sq"]');assert.equal(await a.eval(`document.querySelectorAll('.word-row').length`),2);
    await a.click('.word-row button');assert.equal(await a.eval(`document.querySelectorAll('.word-row').length`),1);
    await a.click('#back');await a.eval(`document.querySelector('#filter').value='courses';document.querySelector('#filter').dispatchEvent(new Event('change'))`);
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/language-desktop.png',Buffer.from(shot.data,'base64'));
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);await a.click('[data-language="ar"]');await a.click('#flash');
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    const mobileShot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/language-mobile.png',Buffer.from(mobileShot.data,'base64'));
    await a.click('#tutor-start');await a.click('#tutor-begin');
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    const tutorShot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:false},a.sessionId);fs.writeFileSync('/private/tmp/language-tutor-mobile.png',Buffer.from(tutorShot.data,'base64'));
    await a.eval(`const s=JSON.parse(localStorage.getItem('kiddosproutState'));s.children[0].appRules.arcade='blocked';localStorage.setItem('kiddosproutState',JSON.stringify(s))`);
    await a.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);
    assert.equal(await a.eval(`document.querySelector('script[src="game.js"]')===null`),true);
    assert.deepEqual(errors,[]);console.log('PASS: catalogue search, pagination, unavailable lessons, safe custom cards, saved collection, voice fallback, mobile RTL and approval gates');
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
