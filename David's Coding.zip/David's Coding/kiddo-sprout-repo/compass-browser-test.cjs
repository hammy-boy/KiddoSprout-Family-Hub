// Browser integration checks using the Chrome already installed on this Mac.
// No downloaded packages or browser binaries are required.
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const assert = require('node:assert/strict');
const http=require('node:http');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

async function main() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'chess-browser-'));
  const server=http.createServer((req,res)=>{const name=req.url==='/'?'games/index.html':req.url.split('?')[0].slice(1);if(!(name.startsWith('games/')||name==='kid-hub-gate.js')||name.includes('..')){res.writeHead(404);return res.end()}res.setHeader('Content-Type',name.endsWith('.js')?'text/javascript':name.endsWith('.css')?'text/css':name.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(path.join(__dirname,name.endsWith('/')?name+'index.html':name)))});
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const chrome = spawn(process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', ['--headless=new', '--remote-debugging-port=0', '--user-data-dir='+path.join(folder,'profile'), '--no-first-run', '--no-default-browser-check', 'about:blank'], { stdio:['ignore','ignore','pipe'] });
  let ws;
  try {
    const endpoint = await new Promise((resolve,reject) => {
      let stderr=''; const timeout=setTimeout(()=>reject(Error('Chrome startup timed out')),15000);
      chrome.once('error',reject);
      chrome.stderr.on('data',chunk=>{stderr+=chunk;const m=stderr.match(/DevTools listening on (ws:\/\/[^\s]+)/);if(m){clearTimeout(timeout);resolve(m[1])}});
      chrome.once('exit',code=>{clearTimeout(timeout);reject(Error('Chrome exited '+code+' '+stderr.slice(-1000)))});
    });
    ws = new WebSocket(endpoint);
    await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true})});
    let id=0; const pending=new Map(), errors=[];
    ws.addEventListener('message',event=>{const m=JSON.parse(event.data);if(m.id){const p=pending.get(m.id);if(p){clearTimeout(p.timer);pending.delete(m.id);m.error?p.reject(Error(m.error.message)):p.resolve(m.result)}}else if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
    function send(method,params={},sessionId){return new Promise((resolve,reject)=>{const requestId=++id;const timer=setTimeout(()=>{pending.delete(requestId);reject(Error('CDP timeout: '+method))},15000);pending.set(requestId,{resolve,reject,timer});ws.send(JSON.stringify({id:requestId,method,params,...(sessionId?{sessionId}:{})}))})}
    async function page(){const context=await send('Target.createBrowserContext');const target=await send('Target.createTarget',{url:'about:blank',browserContextId:context.browserContextId});const {sessionId}=await send('Target.attachToTarget',{targetId:target.targetId,flatten:true});await send('Runtime.enable',{},sessionId);await send('Page.enable',{},sessionId);await send('Page.navigate',{url:base+'/games/'},sessionId);const p={sessionId,async eval(expression){const r=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true},sessionId);if(r.exceptionDetails)throw Error(r.exceptionDetails.exception?.description||r.exceptionDetails.text);return r.result.value},async until(expression){for(let i=0;i<600;i++){if(await this.eval(expression))return;await delay(50)}throw Error('Timed out: '+expression)},async click(selector){await this.eval(`document.querySelector(${JSON.stringify(selector)}).click()`)}};await p.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);return p}
    const a=await page(); console.log('Anonymous gate passed');
    assert.equal(await a.eval(`getComputedStyle(document.querySelector('[data-hub-page]')).display`),'none');
    await a.eval(`localStorage.setItem('kiddosproutState',JSON.stringify({parentAccountCreated:true,activeChild:0,children:[{appRules:{arcade:'allowed'}}]}))`);
    await send('Page.navigate',{url:base+'/games/compass-quest/'},a.sessionId);
    await a.until(`document.querySelectorAll('[data-mission]').length===6`);
    await a.click('[data-direction="W"]');assert.equal(await a.eval(`document.querySelector('#position').textContent`),'You are at A7');assert.equal(await a.eval(`document.querySelector('#message').textContent`),'Try a different path.');
    await a.click('#hint');assert.equal(await a.eval(`document.querySelector('#explanation').textContent.includes('north')`),true);
    for(let mission=0;mission<6;mission++){
      await a.click(`[data-mission="${mission}"]`);
      const path=await a.eval(`(()=>{const m=CompassQuest.missions[${mission}],queue=[[CompassQuest.initial(),[]]],seen=new Set();while(queue.length){const [s,p]=queue.shift();if(s.won)return p;const key=[s.x,s.y,s.stop].join(':');if(seen.has(key))continue;seen.add(key);for(const d of ['N','E','S','W']){const next=CompassQuest.move(s,d,m);if(!next.error)queue.push([next,[...p,d]])}}throw Error('No route')})()`);
      for(const d of path)await a.eval(`document.dispatchEvent(new KeyboardEvent('keydown',{key:'${d.toLowerCase()}',bubbles:true}))`);
      assert.equal(await a.eval(`document.querySelector('#task').textContent`),'Expedition complete!');
      assert.equal(await a.eval(`JSON.parse(localStorage.getItem('sprout-compass-quests'))[${mission}]`),path.length);
      assert.equal(await a.eval(`document.querySelectorAll('[data-direction]:disabled').length`),8);console.log('PASS: expedition '+(mission+1));
    }
    await send('Page.reload',{},a.sessionId);await a.until(`document.querySelector('#badge-count')?.textContent==='6 / 6 badges'`);
    await a.click('[data-mission="3"]');await a.click('[data-direction="N"]');await a.click('#reset');assert.equal(await a.eval(`document.querySelector('#moves').textContent`),'0 moves');
    const shot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/compass-desktop.png',Buffer.from(shot.data,'base64'));
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true},a.sessionId);
    assert.equal(await a.eval(`document.documentElement.scrollWidth<=innerWidth`),true);
    await a.click('.mobile-directions [data-direction="N"]');assert.equal(await a.eval(`document.querySelector('#position').textContent`),'You are at A6');
    const mobileShot=await send('Page.captureScreenshot',{format:'png',captureBeyondViewport:true},a.sessionId);fs.writeFileSync('/private/tmp/compass-mobile.png',Buffer.from(mobileShot.data,'base64'));
    await a.eval(`const s=JSON.parse(localStorage.getItem('kiddosproutState'));s.children[0].appRules.arcade='blocked';localStorage.setItem('kiddosproutState',JSON.stringify(s))`);
    await a.until(`document.querySelector('[data-hub-lock]') && !document.querySelector('[data-hub-lock]').classList.contains('hidden')`);
    assert.equal(await a.eval(`document.querySelector('script[src="game.js"]')===null`),true);
    assert.deepEqual(errors,[]);console.log('PASS: compass directions, route completion, hints, saved records, reset, mobile and approval gates');
  }finally{ws?.close();chrome.kill();await new Promise(r=>server.close(r))}
}
main().catch(e=>{console.error(e);process.exitCode=1});
